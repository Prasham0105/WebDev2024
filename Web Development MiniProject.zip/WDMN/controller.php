<?php
session_start();
require 'db.php'; // Database connection

// Main Controller to Handle POST Requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check which action to perform
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'login':
                handleLogin($conn);
                break;
            case 'register':
                handleRegister($conn);
                break;
            case 'signup':
                handleSignup($conn);
                break;
            case 'upload':
                handleUpload($conn);
                break;
            case 'forgot_password':
                handleForgotPassword($conn);
                break;
            case 'edit_profile':
                handleEditProfile($conn);
                break;
            default:
                echo "Invalid action specified.";
                break;
        }
    } else {
        echo "No action specified.";
    }
}

// Function to handle login
function handleLogin($conn) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            header("Location: dashboard.php");
            exit;
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "User not found!";
    }
}

// Function to handle registration
function handleRegister($conn) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "INSERT INTO users (first_name, last_name, email, username, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", $first_name, $last_name, $email, $username, $password);
    $stmt->execute();

    header("Location: index.html");
    exit;
}

// Function to handle signup
function handleSignup($conn) {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "INSERT INTO users (email, password) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();

    header("Location: index.html");
    exit;
}

// Function to handle document upload
function handleUpload($conn) {
    if (isset($_SESSION['user_id'])) {
        $title = $_POST['docTitle'];
        $description = $_POST['docDescription'];
        $category = $_POST['docCategory'];
        $user_id = $_SESSION['user_id'];
        $file = $_FILES['docFile'];

        $file_path = 'uploads/' . basename($file['name']);
        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            $query = "INSERT INTO documents (user_id, title, description, file_path, category) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("issss", $user_id, $title, $description, $file_path, $category);
            $stmt->execute();
            
            echo "Document uploaded successfully!";
        } else {
            echo "Error uploading document.";
        }
    } else {
        echo "User not logged in.";
    }
}

// Function to handle password reset
function handleForgotPassword($conn) {
    $email = $_POST['email'];
    $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "UPDATE users SET password = ? WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $new_password, $email);
    $stmt->execute();

    echo "Password updated successfully!";
}

// Function to handle profile editing
function handleEditProfile($conn) {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $username = $_POST['username'];

        $query = "UPDATE users SET first_name = ?, last_name = ?, email = ?, username = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssi", $first_name, $last_name, $email, $username, $user_id);
        $stmt->execute();

        echo "Profile updated successfully!";
    } else {
        echo "User not logged in.";
    }
}
?>
