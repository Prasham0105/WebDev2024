<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Project Management</title>
    <link rel="stylesheet" href="dashboard.css">
    <link rel="icon" href="Logo.png" type="image/x-icon"/>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">
                <img src="Logo.png" alt="Project Management Logo" class="logo-img">
                <h2>Project Manager</h2>
            </div>
            <nav class="nav-links">
                <a href="dashboard.php" class="nav-item active">Dashboard</a>
                <a href="upload.html" class="nav-item">Upload Document</a>
                <a href="Edit.html" class="nav-item">Edit Profile</a>
                <a href="forgot.html" class="nav-item">Change Password</a>
                <a href="logout.php" class="nav-item">Logout</a>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <h1>Welcome to Your Dashboard</h1>
                <p>Manage your projects efficiently and keep track of your documents.</p>
            </header>

            <!-- Projects Section -->
            <section class="projects">
                <h2>Your Projects</h2>
                <div class="project-list">
                    <!-- Example Project Card -->
                    <div class="project-card">
                        <h3>Project Name</h3>
                        <p>Status: <span class="status">In Progress</span></p>
                        <p>Due Date: 12/12/2024</p>
                        <button class="view-btn">View Details</button>
                    </div>
                    <!-- Add more project cards dynamically with PHP if needed -->
                </div>
            </section>

            <!-- Document Section -->
            <section class="documents">
                <h2>Recent Documents</h2>
                <div class="document-list">
                    <!-- Example Document Card -->
                    <div class="document-card">
                        <h3>Document Title</h3>
                        <p>Category: Reports</p>
                        <p>Date Uploaded: 11/10/2024</p>
                        <button class="download-btn">Download</button>
                    </div>
                    <!-- Add more document cards dynamically with PHP if needed -->
                </div>
            </section>
        </main>
    </div>
</body>
</html>
