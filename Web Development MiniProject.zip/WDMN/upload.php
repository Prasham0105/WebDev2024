<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $title = $_POST['docTitle'];
    $description = $_POST['docDescription'];
    $category = $_POST['docCategory'];
    $user_id = $_SESSION['user_id'];
    $file = $_FILES['docFile'];

    $file_path = 'uploads/' . basename($file['name']);
    move_uploaded_file($file['tmp_name'], $file_path);

    $query = "INSERT INTO documents (user_id, title, description, file_path, category) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("issss", $user_id, $title, $description, $file_path, $category);
    $stmt->execute();

    echo "Document uploaded successfully!";
}
?>
